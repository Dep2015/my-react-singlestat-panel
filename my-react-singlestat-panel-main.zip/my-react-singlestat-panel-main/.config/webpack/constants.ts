export const SOURCE_DIR = 'src';
export const DIST_DIR = 'dist';
